import os
import requests
import sqlite3
import logging
from cryptography.fernet import Fernet
import bcrypt

API_KEY = os.getenv("API_KEY")
DB_CONNECTION_STRING = os.getenv("DATABASE_URL")
UPLOAD_BUCKET = os.getenv("UPLOAD_BUCKET")

class DataProcessor:
    def __init__(self):
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        if not API_KEY:
            raise RuntimeError("Missing API_KEY")
        self.session = requests.Session()
        self.session.verify = True

    def connect_to_database(self):
        try:
            conn = sqlite3.connect("app_data.db")
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_data (
                    id INTEGER PRIMARY KEY,
                    username TEXT,
                    password TEXT,
                    credit_card TEXT,
                    ssn TEXT,
                    created_at TIMESTAMP
                )
            """)
            conn.commit()
            return conn, cursor
        except Exception:
            self.logger.error("Database connection failed.")
            return None, None

    def fetch_user_data(self, user_id):
        conn, cursor = self.connect_to_database()
        if not cursor:
            return None
        try:
            cursor.execute("SELECT * FROM user_data WHERE id = ?", (user_id,))
            result = cursor.fetchone()
            conn.close()
            return result
        except Exception:
            self.logger.error("Query failed.")
            return None
